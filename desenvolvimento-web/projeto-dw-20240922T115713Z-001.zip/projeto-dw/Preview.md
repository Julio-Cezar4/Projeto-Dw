| Campo       | Valor                                                                                           |
|-------------|-------------------------------------------------------------------------------------------------|
| **name**    | MACtrace                                                                                       |
| **description** | Descubra a identidade dos fabricantes com o MacTrace.                                        |
| **repository** | [GitHub Repository](https://github.com/l3l0ch/Projeto-Dw)                                      |
| **category** | type: subject <br> subject: dw <br> semester: 2024.1 <br> course: cstrc <br> campus: ifpb-jp |
| **tags**    | html, css, javascript                                                                           |
| **owners**  | 20222380017, 20222380024, 20211380027                                                            |
| **preview** | ![Preview](https://raw.githubusercontent.com/l3l0ch/Projeto-Dw/main/Projeto-main/projeto/image.png) |

